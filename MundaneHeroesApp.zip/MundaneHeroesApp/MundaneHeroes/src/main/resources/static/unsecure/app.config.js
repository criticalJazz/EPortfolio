'use strict';

angular.
module('phonecatApp').
config(['$routeProvider',
    function config($routeProvider) {
        $routeProvider.
        when('/', {
            template: '<fourm></fourm>'
        }).
        when('/fourms/:postId', {
            template: '<post-detail></post-detail>'
        })
      //  otherwise('/fourms');
    }
]);






/**
var mundaneApp = angular.module('fourmApp', []);

mundaneApp.controller('FourmController', function FourmController($scope, $http){

    //var route = $routeParams.param();

    $http.get("http://localhost:8080/posts").then(function (response) {

        $scope.posts = response.data;

    });




    $http.get("localhost:8082/users").then(function (response) {
        $scope.users = response.data;

    });



    $http.get("localhost:8082/comment").then(function (response) {
        $scope.thread = response.data;
    });

    });

 **/