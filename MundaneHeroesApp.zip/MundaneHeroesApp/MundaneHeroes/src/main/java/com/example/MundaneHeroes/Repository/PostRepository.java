package com.example.MundaneHeroes.Repository;

import com.example.MundaneHeroes.Model.Post;
import com.example.MundaneHeroes.Model.User;
import org.hibernate.sql.Select;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PostRepository extends JpaRepository<Post, Integer> {

    @Override
    <S extends Post> S save(S s);

    @Override
    List<Post> findAll();

    List<Post> findAllByUser(String user);

    Post findById(int id);

    List<Post> findByOrderByFourmOrderDesc();

    Post findFirstByOrderByFourmOrderDesc();


    @Modifying
    @Query("update Post p set p.fourmOrder = :x where p.id = :y")
    void updatePosts(@Param("x") int x, @Param("y") int y);

}
