package com.example.chess.Controller;


import com.example.chess.Model.Chat;
import com.example.chess.Model.Coord;
import com.example.chess.Model.Piece;
import com.example.chess.Service.PieceService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:8000")
public class PieceController {

    private PieceService pieceService;

    public PieceController(PieceService pieceService)
    {
        this.pieceService = pieceService;
    }


    @RequestMapping(value = "/chess", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Piece> getAllPieces(){
        return pieceService.getAllPieces();

    }

    @RequestMapping(value = "/chess/{x}/{y}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Piece findPiece(@PathVariable int x, @PathVariable int y){
        return pieceService.fineOne(x, y);

    }

    @RequestMapping(value = "/coordinates", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void pieceMove(@RequestBody Coord coord){
        pieceService.saveCoord(coord);


    }
    @RequestMapping(value = "/coordinates", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Coord> getAllCoords() {
        return pieceService.getAllCoords();
    }

    @RequestMapping(value = "/chat", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void newChat(@RequestBody Chat chat)
    {
        pieceService.saveChat(chat);
    }

    @RequestMapping(value = "/chat", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Chat> getAllChat()
    {
        return pieceService.getAllChat();
    }


}
