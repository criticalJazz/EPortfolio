'use strict';


var postApp = angular.module('postApp', []);

postApp.controller('PostController', function PostController($scope, $http) {


    $http.get("http://localhost:8082/currentUser").then(function (response){
        $scope.userName = response.data;
    });


    $http.get("Principal.txt").then(function (response){
        $scope.userNamee = response.data;
    });


    $scope.text = "hello";
    $scope.postText = null;
    $scope.postTitle = null;
    $scope.user = null;
    $scope.postDate = null
    $scope.postdata = function (postText, postTitle, user, postDate) {
        var data = {
            postText: postText,
            postTitle: postTitle,
            user: user,
            postDate: postDate

        };


        $http.post("http://localhost:8082/posts", JSON.stringify(data)).then(function (response) {
            if (response.data)
                $scope.msg = "Post Data Submitted Successfully!";

        }, function (response) {
            $scope.msg = JSON.stringify(data)
            $scope.statusval = response.status;
            $scope.statustext = response.statusText;
            $scope.headers = response.xhrStatus;


        })

        location.replace("http://localhost:8082/secure/securedPage.html#!/")
    };

})