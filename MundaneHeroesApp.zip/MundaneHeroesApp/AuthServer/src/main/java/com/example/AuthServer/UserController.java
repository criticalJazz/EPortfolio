package com.example.AuthServer;


import com.example.AuthServer.Model.User;
import com.example.AuthServer.Service.UserService;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.PermitAll;
import java.security.Principal;

@RestController
@CrossOrigin(origins = "http://localhost:8082")
public class UserController {


    private UserService userService;
    @GetMapping("/user/me")
    public Principal user(Principal principal)
    {
        return principal;
    }



    /**
    @GetMapping("/user/currentUser")
    public String currentUser(@AuthenticationPrincipal Principal principal)
    {
        System.out.print("name:" + principal.getName());
        return principal.getName();
    }
    **/


    public UserController(UserService userService){
        this.userService = userService;
    }

    @PermitAll
    @RequestMapping(value = "/users", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void saveUser(@RequestBody User user)
    {
        if(user.getEmail()==null||user.getPassword()==null||user.getUsername()==null)//some basic rules on account creation
        {
            return;
        }
        else if(user.getPassword().length()<4)
        {
            return;
        }
        String encodedPassword = new BCryptPasswordEncoder().encode(user.getPassword());
        user.setPassword(encodedPassword);
        //System.out.print(encodedPassword);
        userService.saveUser(user);
    }


}
