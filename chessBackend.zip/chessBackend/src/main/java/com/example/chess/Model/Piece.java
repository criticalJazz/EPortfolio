package com.example.chess.Model;



import javax.persistence.*;


@Entity
public class Piece {


    @Column
    private String type;
    @Column
    private int y;
    @Column
    private int x;
    @GeneratedValue
    @Id
    @Column
    private int id;
    @Column
    private boolean selected;
    @Column
    private int team;


    public Piece()
    {

    }

    public Piece(String typet, int xx, int yy, int idd, int teamm)
    {
        type = typet;
        y = yy;
        x = xx;
        selected = false;
        id = idd;
        team = teamm;



    }



    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getType() {
        return type;
    }

    public int getTeam() {return team; }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public boolean getSelected()
    {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public void setTeam(int team) {
        this.team = team;
    }
}
