package com.example.AuthServer.Service;


import com.example.AuthServer.Model.User;
import com.example.AuthServer.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {


    @Autowired
    UserRepository userRepository;



    public void saveUser(User user)
    {
        //System.out.print(passwordEncoder.encode(user.getPassword()));

        userRepository.save(user);
    }

    public List<User> allUsers(){
        return userRepository.findAll();
    }

    @Override//userDetailsService exists to override this method
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {


        org.springframework.security.core.userdetails.User.UserBuilder userBuilder = null;
        User user = userRepository.findByUsername(username);

        if(user==null)
        {
            //return null maybe?
            throw new UsernameNotFoundException("error");
        }
        else
        {
            //userBuilder.username(user.getUsername());
            //userBuilder.password( new BCryptPasswordEncoder().encode(user.getPassword()));
            //userBuilder.roles("USER");
        }
        UserDetails userDetails = new UserDetailsImpl(user);

        System.out.println("finished");
        //return userBuilder.build();
        //userDetails

        return userDetails;

        //return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword());
    }

    private Collection<? extends GrantedAuthority> getAuthorities(String role)
    {
        return Collections.singletonList(new SimpleGrantedAuthority(role));
    }
}
