'use strict';


angular.module('fourm', []);