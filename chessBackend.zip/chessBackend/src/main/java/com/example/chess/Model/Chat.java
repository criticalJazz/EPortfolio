package com.example.chess.Model;


import javax.persistence.*;

@Entity
public class Chat {

    @GeneratedValue
    @Id
    @Column
    private int chatID;

    @Column
    private String chatMsg;

    public int getChatID() {
        return chatID;
    }

    public String getChatMsg() {
        return chatMsg;
    }

    public void setChatID(int chatID) {
        this.chatID = chatID;
    }

    public void setChatMsg(String chatMsg) {
        this.chatMsg = chatMsg;
    }
}
