'use strict';

angular.
module('postDetail').
component('postDetail', {
    templateUrl: 'post-detail/post-detail.template.html',
    controller: ['$http', '$routeParams',
        function postDetailController($http, $routeParams) {
            var self = this;

            $http.get("http://localhost:8082/posts/" + $routeParams.postId).then(function(response) {
                self.post = response.data;
            });

            $http.get("http://localhost:8082/comments/" + $routeParams.postId).then(function(response) {
                self.comments = response.data;
            });

            self.postId = $routeParams.postId;
            self.user = null;
            self.commentDate = null;
            self.commentText = null;

            self.commentdata = function (commentText, commentDate, user, postId) {
                var data = {
                    commentText: commentText,
                    commentDate: commentDate,
                    user: user,
                    postId: $routeParams.postId

                };

                $http.post("http://localhost:8082/comments", JSON.stringify(data)).then(function (response) {
                    if (response.data)
                        self.msg = "Post Data Submitted Successfully!";

                }, function (response) {
                    self.msg = JSON.stringify(data)
                    self.statusval = response.status;
                    self.statustext = response.statusText;
                    self.headers = response.xhrStatus;


                })

                location.reload();
            };

        }
    ]
});