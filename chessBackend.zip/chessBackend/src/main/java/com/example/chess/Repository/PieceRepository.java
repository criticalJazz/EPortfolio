package com.example.chess.Repository;


import com.example.chess.Model.Piece;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PieceRepository extends JpaRepository<Piece, Integer> {


    <S extends Piece> S save(S s);


    Piece findById(int integer);

    Piece findByXAndY(int x, int y);

    void deleteByXAndY(int x, int y);

    @Override
    void delete(Piece piece);

    List<Piece> findAll();

    void deleteAll();


    Piece findBySelected(boolean type);

    @Modifying
    @Query("update Piece p set p.selected = true where p.id = :ii")
    void activatePieceWith(@Param("ii") int x);


    @Modifying
    @Query("update Piece p set p.selected = false  where p.selected = true")
    void setAllFalse();

    @Modifying
    @Query("update Piece p set p.x = :xx where p.id = :ii")
    void movePieceX(@Param("ii") int ii, @Param("xx") int xx);

    @Modifying
    @Query("update Piece p set p.y = :xx where p.id = :ii")
    void movePieceY(@Param("ii") int ii, @Param("xx") int xx);


}
