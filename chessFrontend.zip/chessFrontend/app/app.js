'use strict';

// Define the `phonecatApp` module
var phonecatApp = angular.module('phonecatApp', []);

// Define the `PhoneListController` controller on the `phonecatApp` module
phonecatApp.controller('PhoneListController', function PhoneListController($scope, $http) {
  
  $http.get("http://localhost:8080/chess/1/1").then (function (response) {
        $scope.oneone = response.data;
      });
  
  $http.get("http://localhost:8080/chess/1/2").then (function (response) {
        $scope.onetwo = response.data;
      });
  $http.get("http://localhost:8080/chess/1/3").then (function (response) {
        $scope.onethree = response.data;
      });
  $http.get("http://localhost:8080/chess/1/4").then (function (response) {
        $scope.onefour = response.data;
      });
  $http.get("http://localhost:8080/chess/1/5").then (function (response) {
        $scope.onefive = response.data;
      });
  $http.get("http://localhost:8080/chess/1/6").then (function (response) {
        $scope.onesix = response.data;
      });
  $http.get("http://localhost:8080/chess/1/7").then (function (response) {
        $scope.oneseven = response.data;
      });
  $http.get("http://localhost:8080/chess/1/8").then (function (response) {
        $scope.oneeight = response.data;
      });
  



  $http.get("http://localhost:8080/chess/2/1").then (function (response) {
        $scope.twoone = response.data;
      });
  $http.get("http://localhost:8080/chess/2/2").then (function (response) {
        $scope.twotwo = response.data;
      });
  $http.get("http://localhost:8080/chess/2/3").then (function (response) {
        $scope.twothree = response.data;
      });
  $http.get("http://localhost:8080/chess/2/4").then (function (response) {
        $scope.twofour = response.data;
      });
  $http.get("http://localhost:8080/chess/2/5").then (function (response) {
        $scope.twofive = response.data;
      });
  $http.get("http://localhost:8080/chess/2/6").then (function (response) {
        $scope.twosix = response.data;
      });
  $http.get("http://localhost:8080/chess/2/7").then (function (response) {
        $scope.twoseven = response.data;
      });
  $http.get("http://localhost:8080/chess/2/8").then (function (response) {
        $scope.twoeight = response.data;
      });







  $http.get("http://localhost:8080/chess/3/1").then (function (response) {
        $scope.threeone = response.data;
      });
  $http.get("http://localhost:8080/chess/3/2").then (function (response) {
        $scope.threetwo = response.data;
      });
  $http.get("http://localhost:8080/chess/3/3").then (function (response) {
        $scope.threethree = response.data;
      });
  $http.get("http://localhost:8080/chess/3/4").then (function (response) {
        $scope.threefour = response.data;
      });
  $http.get("http://localhost:8080/chess/3/5").then (function (response) {
        $scope.threefive = response.data;
      });
  $http.get("http://localhost:8080/chess/3/6").then (function (response) {
        $scope.threesix = response.data;
      });
  $http.get("http://localhost:8080/chess/3/7").then (function (response) {
        $scope.threeseven = response.data;
      });
  $http.get("http://localhost:8080/chess/3/8").then (function (response) {
        $scope.threeeight = response.data;
      });







  $http.get("http://localhost:8080/chess/4/1").then (function (response) {
        $scope.fourone = response.data;
      });
  $http.get("http://localhost:8080/chess/4/2").then (function (response) {
        $scope.fourtwo = response.data;
      });
  $http.get("http://localhost:8080/chess/4/3").then (function (response) {
        $scope.fourthree = response.data;
      });
  $http.get("http://localhost:8080/chess/4/4").then (function (response) {
        $scope.fourfour = response.data;
      });
  $http.get("http://localhost:8080/chess/4/5").then (function (response) {
        $scope.fourfive = response.data;
      });
  $http.get("http://localhost:8080/chess/4/6").then (function (response) {
        $scope.foursix = response.data;
      });
  $http.get("http://localhost:8080/chess/4/7").then (function (response) {
        $scope.fourseven = response.data;
      });
  $http.get("http://localhost:8080/chess/4/8").then (function (response) {
        $scope.foureight = response.data;
      });






  $http.get("http://localhost:8080/chess/5/1").then (function (response) {
        $scope.fiveone = response.data;
      });
  $http.get("http://localhost:8080/chess/5/2").then (function (response) {
        $scope.fivetwo = response.data;
      });
  $http.get("http://localhost:8080/chess/5/3").then (function (response) {
        $scope.fivethree = response.data;
      });
  $http.get("http://localhost:8080/chess/5/4").then (function (response) {
        $scope.fivefour = response.data;
      });
  $http.get("http://localhost:8080/chess/5/5").then (function (response) {
        $scope.fivefive = response.data;
      });
  $http.get("http://localhost:8080/chess/5/6").then (function (response) {
        $scope.fivesix = response.data;
      });
  $http.get("http://localhost:8080/chess/5/7").then (function (response) {
        $scope.fiveseven = response.data;
      });
  $http.get("http://localhost:8080/chess/5/8").then (function (response) {
        $scope.fiveeight = response.data;
      });







  $http.get("http://localhost:8080/chess/6/1").then (function (response) {
        $scope.sixone = response.data;
      });
  $http.get("http://localhost:8080/chess/6/2").then (function (response) {
        $scope.sixtwo = response.data;
      });
  $http.get("http://localhost:8080/chess/6/3").then (function (response) {
        $scope.sixthree = response.data;
      });
  $http.get("http://localhost:8080/chess/6/4").then (function (response) {
        $scope.sixfour = response.data;
      });
  $http.get("http://localhost:8080/chess/6/5").then (function (response) {
        $scope.sixfive = response.data;
      });
  $http.get("http://localhost:8080/chess/6/6").then (function (response) {
        $scope.sixsix = response.data;
      });
  $http.get("http://localhost:8080/chess/6/7").then (function (response) {
        $scope.sixseven = response.data;
      });
  $http.get("http://localhost:8080/chess/6/8").then (function (response) {
        $scope.sixeight = response.data;
      });






  $http.get("http://localhost:8080/chess/7/1").then (function (response) {
        $scope.sevenone = response.data;
      });
  $http.get("http://localhost:8080/chess/7/2").then (function (response) {
        $scope.seventwo = response.data;
      });
  $http.get("http://localhost:8080/chess/7/3").then (function (response) {
        $scope.seventhree = response.data;
      });
  $http.get("http://localhost:8080/chess/7/4").then (function (response) {
        $scope.sevenfour = response.data;
      });
  $http.get("http://localhost:8080/chess/7/5").then (function (response) {
        $scope.sevenfive = response.data;
      });
  $http.get("http://localhost:8080/chess/7/6").then (function (response) {
        $scope.sevensix = response.data;
      });
  $http.get("http://localhost:8080/chess/7/7").then (function (response) {
        $scope.sevenseven = response.data;
      });
  $http.get("http://localhost:8080/chess/7/8").then (function (response) {
        $scope.seveneight = response.data;
      });







  $http.get("http://localhost:8080/chess/8/1").then (function (response) {
        $scope.eightone = response.data;
      });
  $http.get("http://localhost:8080/chess/8/2").then (function (response) {
        $scope.eighttwo = response.data;
      });
  $http.get("http://localhost:8080/chess/8/3").then (function (response) {
        $scope.eightthree = response.data;
      });
  $http.get("http://localhost:8080/chess/8/4").then (function (response) {
        $scope.eightfour = response.data;
      });
  $http.get("http://localhost:8080/chess/8/5").then (function (response) {
        $scope.eightfive = response.data;
      });
  $http.get("http://localhost:8080/chess/8/6").then (function (response) {
        $scope.eightsix = response.data;
      });
  $http.get("http://localhost:8080/chess/8/7").then (function (response) {
        $scope.eightseven = response.data;
      });
  $http.get("http://localhost:8080/chess/8/8").then (function (response) {
        $scope.eighteight = response.data;
      });

  $scope.x = null;
  $scope.y = null;


  $scope.postdata = function(x, y){
    var data = {
      x: x,
      y: y

    };


      
   
    $http.post("http://localhost:8080/coordinates", JSON.stringify(data))
    location.reload();

  };








  $http.get("http://localhost:8080/chat").then(function (response){

    $scope.chats = response.data;

    
  });

  $scope.postchat = function(chatMsg){
    var data = {

      chatMsg: chatMsg
    };


    $http.post("http://localhost:8080/chat", JSON.stringify(data))
    location.reload();
  };
});
