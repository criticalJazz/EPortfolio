package com.example.MundaneHeroes.Model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Set;


@Entity
public class Post {

    @Id
    @GeneratedValue
    @Column
    private int id;//id for all posts

    @Column
    private String user;

    @Column
    private String postTitle;//title of the post

    @Column(length = 6000)
    private String postText;//text in the post

    @Column
    private String postDate;//date the post was created

    @Column
    private String avatar;//avatar of user4 who posted it

    @Column
    private int catagory;

    @Column
    private int fourmOrder;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPostTitle() {
        return postTitle;
    }

    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }

    public String getPostText() {
        return postText;
    }

    public void setPostText(String postText) {
        this.postText = postText;
    }

    public String getPostDate() {
        return postDate;
    }

    public void setpostDate(String postDate) {
        this.postDate = postDate;
    }



    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getCatagory() {
        return catagory;
    }

    public void setCatagory(int catagory) {
        this.catagory = catagory;
    }

    public int getFourmOrder() {
        return fourmOrder;
    }

    public void setFourmOrder(int fourmOrder) {
        this.fourmOrder = fourmOrder;
    }
}

