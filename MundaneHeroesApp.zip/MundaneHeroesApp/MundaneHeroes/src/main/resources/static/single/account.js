'use strict';


var userApp = angular.module('userApp', []);

userApp.controller('UserController', function UserController($scope, $http, $window) {


    $scope.username = null;
    $scope.password = null;
    $scope.email = null;
    $scope.postuser = function(username, password, email){
        var data = {

            username: username,
            password: password,
            email: email
        };


        $http.post("http://localhost:8081/auth/users", JSON.stringify(data)).then (function (response){
            if (response.data)
                $scope.msg = "Post Data Submitted Successfully!";

        }, function (response) {
            $scope.msg = JSON.stringify(data)
            $scope.statusval = response.status;
            $scope.statustext = response.statusText;
            $scope.headers = response.xhrStatus;


        })
        location.replace("http://localhost:8082")

    };

})