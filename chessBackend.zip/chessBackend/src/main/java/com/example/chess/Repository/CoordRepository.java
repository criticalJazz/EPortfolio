package com.example.chess.Repository;

import com.example.chess.Model.Coord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CoordRepository extends JpaRepository<Coord, Integer> {


    <S extends Coord> S save(S s);

    List<Coord> findAll();

}
