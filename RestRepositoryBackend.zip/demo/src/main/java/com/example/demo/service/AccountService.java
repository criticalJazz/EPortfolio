package com.example.demo.service;


import com.example.demo.model.Account;
import com.example.demo.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    @Autowired
    AccountRepository accountRepository;

    public void save(Account account)
    {
        accountRepository.save(account);
    }

    public List<Account> getAccount(Integer name)
    {
        return accountRepository.findAllById(name);
    }

    public List<Account> getAllAccounts()
    {
        return accountRepository.findAll();
    }
}
