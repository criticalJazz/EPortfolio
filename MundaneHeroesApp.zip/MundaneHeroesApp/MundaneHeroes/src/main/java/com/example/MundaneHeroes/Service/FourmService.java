package com.example.MundaneHeroes.Service;


import com.example.MundaneHeroes.Model.Comment;
import com.example.MundaneHeroes.Model.Post;
import com.example.MundaneHeroes.Model.User;
import com.example.MundaneHeroes.Repository.CommentRepository;
import com.example.MundaneHeroes.Repository.PostRepository;
import com.example.MundaneHeroes.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FourmService {

    @Autowired
    PostRepository postRepository;

    @Autowired
    CommentRepository commentRepository;

    @Autowired
    UserRepository userRepository;

    //saving users, posts, and comments
    @Transactional
    public void saveComment(Comment comment)
    {
        int y = 0;
        int x = 0;
        y = comment.getPostId();
        Post post = postRepository.findById(y);
        Post postee = postRepository.findFirstByOrderByFourmOrderDesc();
        x = postee.getFourmOrder() + 1;
        System.out.print(x + " " + y);
        postRepository.updatePosts(x, y);


        commentRepository.save(comment);

    }

    public void savePost(Post post)
    {
        Post poste = postRepository.findFirstByOrderByFourmOrderDesc();
        if(poste != null) {
            post.setFourmOrder(poste.getFourmOrder()+1);
        }
        postRepository.save(post);
    }

    public void saveUser(User user)
    {
        userRepository.save(user);
    }






    //user methods
    public User findUser(String id)
    {
        return userRepository.findByName(id);
    }

    public List<User> allUsers()
    {
        return userRepository.findAll();
    }






    //comment methods
    public List<Comment> allComments()
    {
        return commentRepository.findAll();
    }

    public Comment findComment(int id)
    {
        return commentRepository.findById(id);
    }

    public List<Comment> findCommentByUser(String user)
    {
        return commentRepository.findByUser(user);
    }

    public List<Comment> findCommentByPost(int post)
    {
        return commentRepository.findAllByPostId(post);
    }





    //post methods
    public List<Post> allPosts()
    {
        return postRepository.findAll();
    }

    public Post findPost(int id)
    {
        return postRepository.findById(id);
    }

    public List<Post> postsByUser(String id){ return postRepository.findAllByUser(id);}

    public List<Post> organizedPosts() {return postRepository.findByOrderByFourmOrderDesc();}

   // public List<Post> findPostByUser(User user)
  //  {
   //     return postRepository.findAllByUser(user);
  //  }
}
