'use strict';

angular.
module('postDetail').
component('postDetail', {
    templateUrl: 'post-detail/post-detail.template.html',
    controller: ['$http', '$routeParams',
        function postDetailController($http, $routeParams) {
            var self = this;

            $http.get("http://localhost:8082/posts/" + $routeParams.postId).then(function(response) {
                self.post = response.data;
            });

            $http.get("http://localhost:8082/comments/" + $routeParams.postId).then(function(response) {
                self.comments = response.data;
            });



        }
    ]
});