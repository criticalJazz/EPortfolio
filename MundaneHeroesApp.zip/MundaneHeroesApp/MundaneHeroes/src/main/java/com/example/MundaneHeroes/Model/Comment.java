package com.example.MundaneHeroes.Model;

import javax.persistence.*;
import java.util.Date;


@Entity
public class Comment {

    @Id
    @GeneratedValue
    @Column
    private int id;//id of each post

    @Column
    private int postId;// what post this comment is in

    @Column
    private String user;//what user posted this

    @Column
    private String commentText;//text in the comment

    @Column
    private String commentDate;//date of comment

    @Column
    private String avatar;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPostId() {return postId; }

    public void setPostId(int postId) { this.postId = postId; }

    public String getUser() { return user; }

    public void setUser(String user) { this.user = user; }

    public String getCommentText() {
        return commentText;
    }

    public void setCommentText(String postText) {
        this.commentText = postText;
    }

    public String getCommentDate() {
        return commentDate;
    }

    public void setCommentDate(String postDate) {
        this.commentDate = postDate;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
}
