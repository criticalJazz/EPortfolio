package com.example.MundaneHeroes.Model;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
public class User {




    @Id
    @GeneratedValue
    @Column
    private int id; //id of user, each user has different id

    @Column
    private String name; //name (should probably be a key so no duplicates)

    @Column
    private String avatar;

    @Column
    private Date age;// when the acct was created not used

    @Column
    private boolean banned;  //whether the user is banned NOT CURRENTLY USED

   // @OneToMany(mappedBy = "user")
  //  private Set<Post> posts;

    //@OneToMany(mappedBy = "user")
   // private Set<Comment> comments;

    public int getId()
    {
        return id;
    }

    public void setId(int i)
    {
        id = i;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    // public Set<Post> getPosts() {return posts;}

    //public void setPosts(Set<Post> posts) {this.posts = posts;}

   // public Set<Comment> getComments() {return comments;}

   // public void setComments(Set<Comment> comments) {this.comments = comments;}


}

