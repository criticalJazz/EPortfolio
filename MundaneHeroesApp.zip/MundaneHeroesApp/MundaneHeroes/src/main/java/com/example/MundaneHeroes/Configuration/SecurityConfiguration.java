package com.example.MundaneHeroes.Configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;




@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Override
    public void configure(HttpSecurity http) throws Exception
    {
        //http.antMatcher("/**").authorizeRequests().antMatchers("/", "/login**", "/single/**", "/currentUser", "/posts", "h2-console/**").permitAll().anyRequest().authenticated().and().oauth2Login();

        http.csrf().disable().headers().frameOptions().disable().and().authorizeRequests().antMatchers("/secure/**").authenticated().and().oauth2Login().and().authorizeRequests().antMatchers("h2-console/**").permitAll().and().logout();
    }
}

//http.authorizeRequests().antMatchers("/").permitAll().antMatchers("/h2-console/**", "/posts", "/account.html").permitAll();


//http.antMatcher("/**").authorizeRequests().antMatchers("/securedPage.html#!/**").permitAll().anyRequest().authenticated().and().oauth2Login();
//http.authorizeRequests().antMatchers("/securedPage.html#!/**").authenticated();
//http.csrf().disable();//to be removed b4 production
// http.headers().frameOptions().disable();

//http.antMatcher("/securedPage.html");



/**

package com.example.MundaneHeroes.Configuration;


        import org.springframework.context.annotation.Bean;
        import org.springframework.context.annotation.Configuration;
        import org.springframework.web.servlet.ViewResolver;
        import org.springframework.web.servlet.config.annotation.EnableWebMvc;
        import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
        import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
        import org.springframework.web.servlet.view.InternalResourceViewResolver;


@EnableWebMvc
@Configuration
public class MVCConfiguration implements WebMvcConfigurer {


    @Override
    public void addViewControllers(ViewControllerRegistry registry)
    {
        registry.addViewController("/").setViewName("index");
    }

    @Bean
    public ViewResolver viewResolver(){
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();

        return resolver;
    }
}
**/