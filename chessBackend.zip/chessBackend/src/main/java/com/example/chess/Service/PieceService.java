package com.example.chess.Service;


import com.example.chess.Model.*;
import com.example.chess.Repository.ChatRepository;
import com.example.chess.Repository.CoordRepository;
import com.example.chess.Repository.PieceRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.Random;

@Service
public class PieceService {

    @Autowired
    PieceRepository pieceRepository;

    @Autowired
    CoordRepository coordRepository;


    @Autowired
    ChatRepository chatRepository;


    public void save(Piece piece) {
        pieceRepository.save(piece);

    }

    public void delete(Piece piece) {
        pieceRepository.delete(piece);
    }

    public List<Piece> getAllPieces() {
        return pieceRepository.findAll();
    }

    public Piece fineOne(int x, int y) {
        return pieceRepository.findByXAndY(x, y);
    }

    public void movePiece(int x, int y) {
        int oldx = 0;
        int oldy = 0;
        int id = 0;
        Piece piece = pieceRepository.findBySelected(true);

        oldx = piece.getX();
        oldy = piece.getY();
        id = piece.getId();

        pieceRepository.movePieceX(id, x);
        pieceRepository.movePieceY(id, y);

        pieceRepository.setAllFalse();
    }

    public void selectPiece(int x, int y) {

        Piece piece = pieceRepository.findByXAndY(x, y);

        pieceRepository.setAllFalse();

        piece.setSelected(true);
    }

    @Transactional
    public void saveCoord(Coord coord) {
        int x = coord.getX();
        int y = coord.getY();

        Piece pieceOne = pieceRepository.findByXAndY(x, y);
        Piece piece;
        int xx = 0;
        int yy = 0;
        Random random;
        int number;
        int c = 0;
        if (x == 999) {
            pieceRepository.deleteAll();
            piece = new Piece("pawn", 7, 1, 1, 1);
            pieceOne = null;
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 2, 2, 1);
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 3, 3, 1);
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 4, 4, 1);
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 5, 5, 1);
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 6, 6, 1);
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 7, 7, 1);
            pieceRepository.save(piece);
            piece = new Piece("pawn", 7, 8, 8, 1);
            pieceRepository.save(piece);
            piece = new Piece("rook", 8, 1, 9, 1);
            pieceRepository.save(piece);
            piece = new Piece("rook", 8, 8, 10, 1);
            pieceRepository.save(piece);
            piece = new Piece("knight", 8, 2, 11, 1);
            pieceRepository.save(piece);
            piece = new Piece("knight", 8, 7, 12, 1);
            pieceRepository.save(piece);
            piece = new Piece("bishop", 8, 3, 13, 1);
            pieceRepository.save(piece);
            piece = new Piece("bishop", 8, 6, 14, 1);
            pieceRepository.save(piece);
            piece = new Piece("queen", 8, 4, 15, 1);
            pieceRepository.save(piece);
            piece = new Piece("king", 8, 5, 16, 1);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 1, 17, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 2, 18, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 3, 19, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 4, 20, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 5, 21, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 6, 22, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 7, 23, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackpawn", 2, 8, 24, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackrook", 1, 1, 25, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackrook", 1, 8, 26, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackknight", 1, 2, 27, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackknight", 1, 7, 28, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackbishop", 1, 3, 29, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackbishop", 1, 6, 30, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackqueen", 1, 4, 31, 2);
            pieceRepository.save(piece);
            piece = new Piece("blackking", 1, 5, 32, 2);
            pieceRepository.save(piece);


        } else if (pieceRepository.findBySelected(true) != null) {

            piece = pieceRepository.findBySelected(true);

            if (piece.getType().equals("pawn")) {
                if (pieceOne == null) {
                    if (piece.getX() == 7) {
                        if ((x == 5 || x == 6) && y == piece.getY()) {
                            piece.setX(x);
                            piece.setY(y);
                            pieceRepository.setAllFalse();
                            c = 1;
                        }
                    } else {
                        if (x == (piece.getX() - 1) && y == piece.getY()) {
                            piece.setX(x);
                            piece.setY(y);
                            c = 1;
                            pieceRepository.setAllFalse();
                        }
                    }
                } else {
                    if ((x == (piece.getX() - 1)) && pieceOne.getTeam() == 2) {
                        if (y == (piece.getY() - 1) || y == (piece.getY() + 1)) {
                            pieceRepository.deleteByXAndY(x, y);
                            piece.setX(x);
                            piece.setY(y);
                            pieceRepository.setAllFalse();
                            c = 1;
                        }
                    }
                }
                pieceRepository.setAllFalse();

            } else if (piece.getType().equals("blackpawn")) {
                if ((pieceOne == null)) {
                    if ((piece.getX() == 2) && (y == piece.getY())) {
                        if (x == 3 || x == 4) {
                            piece.setX(x);
                            piece.setY(y);
                            c = 1;
                            pieceRepository.setAllFalse();
                        }
                    } else {
                        if ((x == (piece.getX() + 1)) && (y == piece.getY())) {
                            piece.setX(x);
                            piece.setY(y);
                            c = 1;
                            pieceRepository.setAllFalse();
                        }
                    }
                } else {
                    if ((x == (piece.getX() + 1)) && pieceOne.getTeam() == 1) {
                        if (y == (piece.getY() - 1) || y == (piece.getY() + 1)) {
                            pieceRepository.deleteByXAndY(x, y);
                            piece.setX(x);
                            piece.setY(y);
                            c = 1;
                            pieceRepository.setAllFalse();
                        }
                    }
                }
                pieceRepository.setAllFalse();
            } else if (piece.getType().equals("knight") || piece.getType().equals("blackknight")) {//all eight possible moves for knight
                if ((x == (piece.getX() - 1) || x == (piece.getX() + 1)) && (y == (piece.getY() - 2) || y == (piece.getY() + 2))) {
                    if (pieceRepository.findByXAndY(x, y) != null) {
                        pieceOne = pieceRepository.findByXAndY(x, y);
                        if (pieceOne.getTeam() != piece.getTeam()) {
                            pieceRepository.deleteByXAndY(x, y);
                            piece.setX(x);
                            piece.setY(y);
                            pieceRepository.setAllFalse();
                            c = 1;
                        }

                    } else {
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    }

                } else if (x == (piece.getX() - 2) && y == (piece.getY() + 1)) {
                    if (pieceRepository.findByXAndY(x, y) != null) {
                        pieceRepository.deleteByXAndY(x, y);
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    } else {
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    }
                } else if (x == (piece.getX() + 2) && y == (piece.getY() + 1)) {
                    if (pieceRepository.findByXAndY(x, y) != null) {
                        pieceRepository.deleteByXAndY(x, y);
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    } else {
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    }
                } else if (x == (piece.getX() - 2) && y == (piece.getY() - 1)) {
                    if (pieceRepository.findByXAndY(x, y) != null) {
                        pieceRepository.deleteByXAndY(x, y);
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    } else {
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    }
                } else if (x == (piece.getX() + 2) && y == (piece.getY() - 1)) {
                    if (pieceRepository.findByXAndY(x, y) != null) {
                        pieceRepository.deleteByXAndY(x, y);
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    } else {
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();
                        c = 1;
                    }
                }
                pieceRepository.setAllFalse();


            }
            if (piece.getType().equals("bishop") || piece.getType().equals("queen") || piece.getType().equals("blackqueen") || piece.getType().equals("blackbishop")) {
                xx = x - piece.getX();
                xx = Math.abs(xx);
                yy = y - piece.getY();
                yy = Math.abs(yy);

                if (xx == yy) {
                    if (x > piece.getX() && y > piece.getY()) {
                        for (int i = 1; i <= xx; i++) {
                            if (i == xx) {
                                if (pieceRepository.findByXAndY(x, y) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(x, y);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x - i, y - i) != null) {
                                i = 500;
                            }

                        }
                    } else if (x < piece.getX() && y > piece.getY()) {
                        for (int i = 1; i <= xx; i++) {
                            if (i == xx) {
                                if (pieceRepository.findByXAndY(x, y) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(x, y);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x + i, y - i) != null) {
                                i = 500;
                            }

                        }
                    } else if (x > piece.getX() && y < piece.getY()) {
                        for (int i = 1; i <= xx; i++) {
                            if (i == xx) {
                                if (pieceRepository.findByXAndY(x, y) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(x, y);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x - i, y + i) != null) {
                                i = 500;
                            }

                        }
                    } else if (x < piece.getX() && y < piece.getY()) {
                        for (int i = 1; i <= xx; i++) {
                            if (i == xx) {
                                if (pieceRepository.findByXAndY(x, y) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(x, y);

                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x + i, y + i) != null) {
                                i = 500;
                            }

                        }
                    }
                }
                pieceRepository.setAllFalse();

            } else if (piece.getType().equals("king") || piece.getType().equals("blackking")) {
                if (((x == piece.getX() - 1 || x == piece.getX() + 1) && (y == (piece.getY() + 1) || y == (piece.getY() - 1))) || ((x == piece.getX()) && (y == (piece.getY() + 1) || y == (piece.getY() - 1))) || ((x == piece.getX() - 1 || x == piece.getX() + 1) && (y == (piece.getY())))) {
                    if (pieceRepository.findByXAndY(x, y) != null) {
                        pieceOne = pieceRepository.findByXAndY(x, y);
                        if (piece.getTeam() != pieceOne.getTeam()) {
                            pieceRepository.deleteByXAndY(x, y);
                            piece.setX(x);
                            piece.setY(y);
                            pieceRepository.setAllFalse();

                        }


                    } else {
                        piece.setX(x);
                        piece.setY(y);
                        pieceRepository.setAllFalse();

                    }
                }
                pieceRepository.setAllFalse();
            }


            if (piece.getType().equals("rook") || piece.getType().equals("queen") || piece.getType().equals("blackqueen") || piece.getType().equals("blackrook")) {
                if (x != piece.getX() && y == piece.getY()) {
                    if (x > piece.getX()) {
                        for (int i = piece.getX() + 1; i <= x; i++) {
                            if (i == x) {
                                if (pieceRepository.findByXAndY(i, y) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(i, y);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x + i, y) != null) {
                                i = 500;
                            }
                        }
                    } else {
                        for (int i = piece.getX() - 1; i >= x; i = i - 1) {
                            if (i == x) {
                                if (pieceRepository.findByXAndY(i, y) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(i, y);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x - i, y) != null) {
                                i = -500;
                            }

                        }
                    }

                } else if (x == piece.getX() && y != piece.getY()) {
                    if (y > piece.getY()) {
                        for (int i = piece.getY() + 1; i <= y; i++) {
                            if (i == y) {
                                if (pieceRepository.findByXAndY(x, i) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(x, i);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x, y + i) != null) {
                                i = 500;
                            }

                        }
                    } else {
                        for (int i = piece.getY() - 1; i >= y; i = i - 1) {
                            if (i == y) {
                                if (pieceRepository.findByXAndY(x, i) != null) {
                                    if (pieceOne.getTeam() != piece.getTeam()) {
                                        pieceRepository.setAllFalse();
                                        pieceRepository.deleteByXAndY(x, i);
                                    }
                                }
                                piece.setX(x);
                                piece.setY(y);
                                c = 1;
                            } else if (pieceRepository.findByXAndY(x, y - 1) != null) {
                                i = 500;
                            }

                        }
                    }
                }
                //piece.setX(x);
                //piece.setY(y);

                pieceRepository.setAllFalse();
            }


        } else {
            pieceRepository.setAllFalse();
            pieceOne.setSelected(true);
            pieceRepository.activatePieceWith(pieceOne.getId());
        }

        coordRepository.save(coord);


    }

    public List<Coord> getAllCoords() {
        return coordRepository.findAll();
    }

    public void saveChat(Chat chat) {
        chatRepository.save(chat);
    }

    public List<Chat> getAllChat() {
        return chatRepository.findAll();
    }


}

