package com.example.AuthServer;

import com.example.AuthServer.Model.User;
import com.example.AuthServer.Repository.UserRepository;
import com.example.AuthServer.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@SpringBootApplication
@EnableResourceServer
public class AuthServerApplication {



	public static void main(String[] args) {

		SpringApplication.run(AuthServerApplication.class, args);

	}

}
