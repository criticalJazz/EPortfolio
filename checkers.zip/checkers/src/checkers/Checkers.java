
package checkers;
/**
 * @author taylorwhite
 */
public class Checkers {

    public static void main(String[] args) 
    {
       
        Display a = new Display();
        a.setVisible(true);
        
            
    }
    
}
