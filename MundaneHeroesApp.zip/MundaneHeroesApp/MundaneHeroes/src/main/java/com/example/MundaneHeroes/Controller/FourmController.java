package com.example.MundaneHeroes.Controller;


import com.example.MundaneHeroes.Model.Comment;
import com.example.MundaneHeroes.Model.Post;
import com.example.MundaneHeroes.Model.User;
import com.example.MundaneHeroes.Service.FourmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Random;

@RestController
@CrossOrigin(origins = "http://localhost:8000")
public class FourmController {


    private FourmService fourmService;


    public FourmController(FourmService fourmService)
    {
        this.fourmService=fourmService;
    }


    //post methods

    @RequestMapping(value = "/posts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Post> listPosts()
    {
        return fourmService.allPosts();
    }

    @RequestMapping(value = "/organizedposts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Post> organizedPosts() {return fourmService.organizedPosts();}

    @RequestMapping(value = "/posts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void newPost(@RequestBody Post post, Principal principal)
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        post.setUser(principal.getName());
        post.setpostDate(now.format(dtf));
        int number = 1;


        if(fourmService.findUser(principal.getName())==null)
        {
            Random rand = new Random();
            User user = new User();

            number = rand.nextInt() % 6;

            number = Math.abs(number) + 1;
            System.out.print(number);
            String string = "image" + number;
            System.out.print(string);
            user.setAvatar("image" + number);
            user.setName(principal.getName());
            fourmService.saveUser(user);
            post.setAvatar("image" + number);
        }
        else
        {
            User user = fourmService.findUser(principal.getName());
            post.setAvatar(user.getAvatar());
        }
        fourmService.savePost(post);

    }

    @RequestMapping(value = "/posts/{x}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Post findPosts(@PathVariable int x)
    {
        return fourmService.findPost(x);
    }





    @RequestMapping(value = "/comments", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void newPost(@RequestBody Comment comment, Principal principal)
    {
        comment.setUser(principal.getName());
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        comment.setCommentDate(now.format(dtf));

        int number = 1;
        if(fourmService.findUser(principal.getName())==null)
        {
            Random rand = new Random();
            User user = new User();

            number = rand.nextInt() % 6;
            number = Math.abs(number) + 1;
            System.out.print(number);
            String string = "image" + number;
            System.out.print(string);
            user.setAvatar("image" + number);
            user.setName(principal.getName());
            fourmService.saveUser(user);
            comment.setAvatar("image" + number);
        }
        else
        {
            User user = fourmService.findUser(principal.getName());
            comment.setAvatar(user.getAvatar());
        }
        fourmService.saveComment(comment);

    }

    @RequestMapping(value = "/comments", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Comment> listPost()
    {
        return fourmService.allComments();
    }


    @RequestMapping(value = "/comments/{y}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Comment> findPiece(@PathVariable int y){
        //System.out.print("gotcomments");
        return fourmService.findCommentByPost(y);


    }





/**
    @RequestMapping(value="/",method = RequestMethod.GET)
    public String homepage(){
        return "index";
    }



    @RequestMapping(value = "/comments", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void newPost(@RequestBody Comment comment)
    {
        fourmService.saveComment(comment);
    }

    @RequestMapping(value = "/users", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void newUser(@RequestBody User user)
    {
        fourmService.saveUser(user);
    }







    //post methods
    @RequestMapping(value = "/posts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Post> listPosts()
    {
        return fourmService.allPosts();
    }

    @RequestMapping(value = "/posts/{x}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Post findPosts(@PathVariable int x)
    {
        return fourmService.findPost(x);
    }










    //comment methods
    @RequestMapping(value = "/comments", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Comment> listPost()
    {
        return fourmService.allComments();
    }

    @RequestMapping(value = "/comments/{x}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Comment findPost(@PathVariable int x)
    {
        return fourmService.findComment(x);
    }










    @RequestMapping(value = "/users", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<User> listUsers()
    {
        return fourmService.allUsers();
    }



 **/
    @GetMapping("/currentUser")
    public String securedPage(@AuthenticationPrincipal Principal principal) throws IOException
    {

        if(principal != null) {

            System.out.print("principal");
            System.out.print(principal.getName());
            return principal.getName();
        }
        else
        {
            System.out.print("nuts");
            return "";
        }

    }

}
