'use strict';

// Define the `phonecatApp` module
var demoFrontend = angular.module('demoFrontend', []);


demoFrontend.controller('DemoController', function($scope, $http) {


  $http.get("http://localhost:8080/accounts").then(function (response){

    $scope.accounts = response.data;
    
  });

  //http post function
  $scope.firstName = null;
  $scope.lastName = null;
  $scope.postdata = function(firstName, lastName){
    var data = {
      firstName: firstName,
      lastName: lastName

    };


  $http.post("http://localhost:8080/accounts", JSON.stringify(data)).then (function (response){
    if (response.data)
      $scope.msg = "Post Data Submitted Successfully!";

    }, function (response) {
      $scope.msg = JSON.stringify(data)
      $scope.statusval = response.status;
      $scope.statustext = response.statusText;
      $scope.headers = response.xhrStatus;


  })
  
  }
});
