'use strict';


angular.
module('fourm').
component('fourm', {
    templateUrl: 'fourm/fourm.template.html',
    controller: ['$http', function PhoneListController($http, $scope, $username) {
        var self = this;
        self.orderProp = 'age';



        $http.get("http://localhost:8082/organizedposts").then(function (response){
            self.posts = response.data;
        });

        $http.get('http://localhost:8080/posts').then(function(response) {
            self.phones = response.data;
        });
    }]
});