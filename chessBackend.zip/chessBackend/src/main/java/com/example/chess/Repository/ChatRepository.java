package com.example.chess.Repository;

import com.example.chess.Model.Chat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChatRepository extends JpaRepository<Chat, Integer> {


    @Override
    <S extends Chat> S save(S s);

    @Override
    List<Chat> findAll();
}
