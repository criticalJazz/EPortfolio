'use strict';


angular.module('basic').
component('basic', {
    templateUrl: 'basic/basic.template.html',
});