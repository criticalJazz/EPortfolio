package com.example.AuthServer;

import com.example.AuthServer.Service.UserDetailsImpl;
import com.example.AuthServer.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@Order(1)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Value("${user.oauth.user.username}")
    private String username;

    @Value("${user.oauth.user.password}")
    private String password;

    @Autowired
    private UserService userDetailsService;

    @Override
    protected void configure(HttpSecurity http) throws Exception
    {

        //old code not used anymore
      //http.requestMatchers().antMatchers("/login", "/oauth/authorize").and().authorizeRequests().anyRequest().authenticated().and().formLogin().permitAll();


        http.csrf().disable().headers().frameOptions().disable().and().requestMatchers().antMatchers("/login").and().authorizeRequests().antMatchers("/login").authenticated().and().formLogin().permitAll().and().requestMatchers().antMatchers("/oauth/authorize").and().authorizeRequests().antMatchers("/oauth/authorize").authenticated().and().formLogin().permitAll().and().requestMatchers().antMatchers("/h2-console/**").and().authorizeRequests().antMatchers("/h2-console/**").permitAll().and().requestMatchers().antMatchers("/users").and().authorizeRequests().antMatchers("/users").permitAll().and().requestMatchers().antMatchers("/user/currentUser").and().authorizeRequests().antMatchers("/user/currentUser").permitAll().and().logout();

    }


    @Override
    @Autowired
    protected void configure(AuthenticationManagerBuilder auth) throws Exception
    {
        auth.inMemoryAuthentication().withUser(username).password(passwordEncoder().encode(password)).roles("ADMIN");
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
        auth.inMemoryAuthentication().withUser("User").password(passwordEncoder().encode("abcd")).roles("ADMIN");
        //auth to userService and password encoder
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
}
