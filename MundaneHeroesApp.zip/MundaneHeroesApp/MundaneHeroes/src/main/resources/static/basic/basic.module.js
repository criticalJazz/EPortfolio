'use strict';

// Define the `phoneList` module
angular.module('basic', []);