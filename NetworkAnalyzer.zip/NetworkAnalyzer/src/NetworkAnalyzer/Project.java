/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NetworkAnalyzer;
import javax.swing.*;                      
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.lang.*;

/**
 *
 * @author Taylor
 *
 */
public class Project {

    /**
     * @param args the command line arguments
     */


    public static void main(String[] args) {


        String address;


        
        ipRouter a = new ipRouter();
        a.setVisible(true);


    }
    
}

