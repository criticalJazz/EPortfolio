package com.example.MundaneHeroes.Repository;


import com.example.MundaneHeroes.Model.Comment;
import com.example.MundaneHeroes.Model.Post;
import com.example.MundaneHeroes.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Integer> {
    @Override
    <S extends Comment> S save(S s);

    @Override
    List<Comment> findAll();

    Comment findById(int id);

    //List<Comment> findByPostId(int postID);

    List<Comment> findAllByPostId(int postId);

    List<Comment> findByUser(String userId);
    



}
